class Gato (nombre: String, edad: Int) : Animal(nombre, edad) {
        override fun hacerSonido() {
            println("El gato maulla: ¡Miau, miau!")
        }
    }
