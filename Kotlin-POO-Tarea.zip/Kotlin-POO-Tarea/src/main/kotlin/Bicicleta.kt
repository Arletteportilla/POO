class Bicicleta: Vehiculo {
    override fun acelerar() {
        println("La bicicleta esta acelerando")

    }

}