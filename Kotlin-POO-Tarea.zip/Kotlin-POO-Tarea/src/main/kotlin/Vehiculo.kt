interface Vehiculo {
    fun acelerar()
}
