class Coche : Vehiculo {
    override fun acelerar() {
        println("El coche esta acelerando")
    }
}
