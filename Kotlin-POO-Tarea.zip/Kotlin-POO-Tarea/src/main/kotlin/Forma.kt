abstract class Forma {
    abstract val area: Double
    abstract fun dibujar()
}